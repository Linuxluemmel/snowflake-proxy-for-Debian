
- When editing Go, please run `go fmt` before every commit.

- You may run tests locally with either `go test` or `npm test` for Go and
  JavaScript, respectively.
